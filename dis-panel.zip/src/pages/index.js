// Cards
import UserCard from "../pages/UserProfile/UserCard.vue";

// Forms
import EditProfileForm from "../pages/UserProfile/EditProfileForm.vue";

export { UserCard, EditProfileForm };
