<template>
  <footer class="footer">
  </footer>
</template>
<script>
export default {};
</script>
<style></style>
